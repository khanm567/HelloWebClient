FrebViewer
==========

Azure Website FREB logs are stored in D:\home\Logflies. To view the FREB files we need to download it manually using FTP and investigate all FREB files. There is no single tool available to parse the FREB files for Azure Websites. 
FrebViewer Azure site extension lists URL, Verb, AppPoolName, StatusCode & TimeTaken from all the FREB files as a summary and selecting appropriate request from the list will open the complete FREB File in a new browser tab. There is no need to download and open files from disk.

Features

•	Option to sort & search requests by Status Code, Time Taken, Application Pool Name, Verb, File Name & URL

•	Paging option which allows to display the number of requests in the FREB Viewer

•	One of key important feature “FREB contains keyword” is to search the text and list only the FREB file information which contains that text 
